package com.kahluabear.money_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
